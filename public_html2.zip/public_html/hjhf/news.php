<ul class="list-group">
      <li class="list-group-item mb-2">
         <a href="img/news.png">
            <img src="img/news.png" class="rounded float-left" width="100">
         </a>
         Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
      </li>
      <li class="list-group-item mb-2">
         <a href="img/news.png">
            <img src="img/news.png" class="rounded float-left img-fluid" width="100">
         </a>
         Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</li>
</ul>