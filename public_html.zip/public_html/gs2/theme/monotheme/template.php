<?php if(!defined('IN_GS')){ die('you cannot load this page directly.'); }
?>
<?php include('header.php');?>

    <section
      id="title"
style="background: url('<?php get_theme_url();?>/img/titlebg.jpg');background-size:cover;background-position:center;"
    >
      <div class="col-md-12 h-100 py-5 fog">
        <div class="row h-100 align-items-center">
          
            <div class="col-md-12 text-light text-center">
              <h1><?php get_page_title();?></h1>
             
     
            </div>
          </div>
        </div>
      </div>
    </section>


    <section class="col-md-12 py-5">
<div class="container text-muted">

<?php get_page_content();?>
</div>
    </section>


<?php include('footer.php');?>