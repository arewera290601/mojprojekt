<?php if(!defined('IN_GS')){ die('you cannot load this page directly.'); }
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <title><?php get_page_title();?> | <?php get_site_name()?></title>
    <link
      rel="stylesheet"
      href="https://use.fontawesome.com/releases/v5.7.2/css/all.css"
      integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr"
      crossorigin="anonymous"
    />
    <link rel="stylesheet" href="<?php get_theme_url();?>/bootstrap.min.css" />
    <link rel="stylesheet" href="<?php get_theme_url();?>/style.css" />
    <?php get_header(); ?>
  </head>
  <body>
    <nav class="col-md-12 navigation py-2 sticky-top ">
      <div class="container ">
        <div class="row align-items-center">
          <div class="col-6 ">
            <a href="<?php get_site_url();?>" class="navbar-brand"><?php get_component('mono_name');?></a>
          </div>

          <div class="col-6">
            <button class="navi-btn ml-auto d-block m-0 ">
              <i class="fas fa-bars"></i>
            </button>
          </div>

          <div class="col-md-12 ">
            <ul class="navinavi col-md-12 py-3 text-center">
            <?php get_navigation();?>
            </ul>
          </div>
        </div>
      </div>
    </nav>
