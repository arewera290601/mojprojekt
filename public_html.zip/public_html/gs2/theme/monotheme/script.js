 var navinavi = document.querySelector(".navinavi");
      var naviBtn = document.querySelector(".navi-btn");

      navinavi.classList.add("d-none");
      naviBtn.addEventListener("click", function() {
        navinavi.classList.toggle("d-none");
      });