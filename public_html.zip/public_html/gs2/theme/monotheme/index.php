<?php if(!defined('IN_GS')){ die('you cannot load this page directly.'); }
?>
<?php include('header.php');?>
    <section
      id="hero"
      style="background: url('<?php get_theme_url();?>/img/slider.jpg')"
    >
      <div class="col-md-12 h-100 py-5 fog">
        <div class="row h-100 align-items-center">
          
            <div class="col-md-12 text-light text-center">
              
             
             <div class="col-md-6 mx-auto"> 


             <?php get_component('mono_hero');?>
				 
				 </div>
            </div>
          </div>
        </div>
      </div>
    </section>


    <section class="col-md-12 py-5">
<div class="container">
<div class="row">

    <div class="col-md-4"><img src="<?php get_theme_url();?>/img/box.jpg" class="w-100 mb-2 img-thumbnail shadow-sm"> 
		<?php get_component('mono_box1');?></div>
	
	   <div class="col-md-4"><img src="<?php get_theme_url();?>/img/box.jpg" class="w-100 mb-2 img-thumbnail shadow-sm"> 
		<?php get_component('mono_box2');?></div>

	
	   <div class="col-md-4"><img src="<?php get_theme_url();?>/img/box.jpg" class="w-100 mb-2 img-thumbnail shadow-sm"> 
		<?php get_component('mono_box3');?></div>


</div>
</div>
    </section>



<section class="bg-light py-5">

    <div class="container">
    <div class="row align-items-center">
    <div class="col-md-8 mx-auto">
  
		<?php get_component('mono_left');?>
		
</div>

<div class="col-md-4">
    <img src="<?php get_theme_url();?>/img/rightfoto.jpg" class="img-fluid img-thumbnail shadow-sm">
</div>
</div>
</div>
</section>
<?php include('footer.php');?>