<?php

die("This functionality is deprecated");